package com.example.myapplication.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.model.Absensi

class AbsensiAdapter(private val list: List<Absensi>) :
    RecyclerView.Adapter<AbsensiAdapter.AbsensiViewHolder>() {

    class AbsensiViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTanggal: TextView = view.findViewById(R.id.tvTanggal)
        val tvMasuk: TextView = view.findViewById(R.id.tvMasuk)
        val tvPulang: TextView = view.findViewById(R.id.tvPulang)
        val tvStatus: TextView = view.findViewById(R.id.tvStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AbsensiViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_absensi, parent, false)
        return AbsensiViewHolder(view)
    }

    override fun onBindViewHolder(holder: AbsensiViewHolder, position: Int) {
        val absensi = list[position]
        holder.tvTanggal.text = absensi.tanggal
        holder.tvMasuk.text = absensi.jam_masuk ?: "-"
        holder.tvPulang.text = absensi.jam_pulang ?: "-"
        holder.tvStatus.text = absensi.status ?: "-"
    }

    override fun getItemCount(): Int = list.size
}
