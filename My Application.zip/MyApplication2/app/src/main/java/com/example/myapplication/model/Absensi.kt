package com.example.myapplication.model

data class Absensi(
    val id: String,
    val tanggal: String,
    val jam_masuk: String?,
    val jam_pulang: String?,
    val latitude: String?,
    val longitude: String?,
    val status: String?
)