package com.example.myapplication

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.Group
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication.adapter.AbsensiAdapter
import com.example.myapplication.model.Absensi
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import org.json.JSONArray

class MainActivity : AppCompatActivity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnAbsen: Button
    private lateinit var btnAbsenPulang: Button
    private lateinit var rvRiwayat: RecyclerView

    // --- Kode yang ditambahkan ---
    private lateinit var loginGroup: Group
    private lateinit var dashboardGroup: Group
    // -------------------------

    private lateinit var locationClient: FusedLocationProviderClient

    private var userId: String = ""

    private val LOCATION_PERMISSION_REQUEST_CODE = 1
    private var onLocationPermissionGranted: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnAbsen = findViewById(R.id.btnAbsen)
        btnAbsenPulang = findViewById(R.id.btnAbsenPulang)
        rvRiwayat = findViewById(R.id.rvRiwayat)

        // --- Kode yang ditambahkan ---
        loginGroup = findViewById(R.id.login_group)
        dashboardGroup = findViewById(R.id.dashboard_group)
        // -------------------------

        locationClient = LocationServices.getFusedLocationProviderClient(this)

        rvRiwayat.layoutManager = LinearLayoutManager(this)

        btnLogin.setOnClickListener { login() }

        btnAbsen.setOnClickListener {
            checkLocationPermission {
                getLocationAndSend(true)
            }
        }
        btnAbsenPulang.setOnClickListener {
            checkLocationPermission {
                getLocationAndSend(false)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    onLocationPermissionGranted?.invoke()
                    onLocationPermissionGranted = null
                } else {
                    Toast.makeText(this, "Izin lokasi ditolak. Fitur tidak dapat digunakan.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun checkLocationPermission(action: () -> Unit) {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            action()
        } else {
            onLocationPermissionGranted = action
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun login() {
        val email = etEmail.text.toString()
        val password = etPassword.text.toString()

        val url = "http://10.0.2.2/absensi/login.php"

        val request = object : StringRequest(
            Method.POST, url,
            { response ->
                try {
                    val json = org.json.JSONObject(response)
                    if (json.getBoolean("status")) {
                        userId = json.getString("id")
                        Toast.makeText(this, "Login sukses", Toast.LENGTH_SHORT).show()
                        
                        // --- Kode yang ditambahkan untuk mengubah tampilan ---
                        loginGroup.visibility = View.GONE
                        dashboardGroup.visibility = View.VISIBLE
                        // --------------------------------------------------

                        loadRiwayat()
                    } else {
                        Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) { e.printStackTrace() }
            },
            { error -> Toast.makeText(this, error.message ?: "Error Volley", Toast.LENGTH_SHORT).show() }
        ) {
            override fun getParams(): MutableMap<String, String> {
                return hashMapOf(
                    "email" to email,
                    "password" to password
                )
            }
        }
        Volley.newRequestQueue(this).add(request)
    }

    private fun getLocationAndSend(isMasuk: Boolean) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
             Toast.makeText(this, "Izin lokasi belum diberikan.", Toast.LENGTH_SHORT).show()
            return
        }

        locationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                if (isMasuk) absenMasuk(location.latitude, location.longitude)
                else absenPulang(location.latitude, location.longitude)
            } else {
                Toast.makeText(this, "Gagal mendapatkan lokasi. Pastikan GPS di perangkat Anda aktif.", Toast.LENGTH_LONG).show()
            }
        }.addOnFailureListener {
            Toast.makeText(this, "Error mendapatkan lokasi: ${it.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun absenMasuk(lat: Double, long: Double) {
        val url = "http://10.0.2.2/absensi/absen_masuk.php"
        val request = object : StringRequest(Method.POST, url,
            { response -> Toast.makeText(this, response, Toast.LENGTH_SHORT).show(); loadRiwayat() },
            { error -> Toast.makeText(this, error.message ?: "Error Volley", Toast.LENGTH_SHORT).show() }
        ) {
            override fun getParams(): MutableMap<String, String> {
                return hashMapOf(
                    "user_id" to userId,
                    "latitude" to lat.toString(),
                    "longitude" to long.toString()
                )
            }
        }
        Volley.newRequestQueue(this).add(request)
    }

    private fun absenPulang(lat: Double, long: Double) {
        val url = "http://10.0.2.2/absensi/absen_pulang.php"
        val request = object : StringRequest(Method.POST, url,
            { response -> Toast.makeText(this, response, Toast.LENGTH_SHORT).show(); loadRiwayat() },
            { error -> Toast.makeText(this, error.message ?: "Error Volley", Toast.LENGTH_SHORT).show() }
        ) {
            override fun getParams(): MutableMap<String, String> {
                return hashMapOf("user_id" to userId)
            }
        }
        Volley.newRequestQueue(this).add(request)
    }

    private fun loadRiwayat() {
        val url = "http://10.0.2.2/absensi/riwayat.php?user_id=$userId"
        val request = StringRequest(Request.Method.GET, url,
            { response ->
                try {
                    val jsonArray = JSONArray(response)
                    val list = mutableListOf<Absensi>()
                    for (i in 0 until jsonArray.length()) {
                        val obj = jsonArray.getJSONObject(i)
                        list.add(Absensi(
                            id = obj.getString("id"),
                            tanggal = obj.getString("tanggal"),
                            jam_masuk = obj.optString("jam_masuk"),
                            jam_pulang = obj.optString("jam_pulang"),
                            latitude = obj.optString("latitude"),
                            longitude = obj.optString("longitude"),
                            status = obj.optString("status")
                        ))
                    }
                    rvRiwayat.adapter = AbsensiAdapter(list)
                } catch (e: Exception) { e.printStackTrace() }
            },
            { error -> Toast.makeText(this, error.message ?: "Error Volley", Toast.LENGTH_SHORT).show() }
        )
        Volley.newRequestQueue(this).add(request)
    }
}
